Vissim Performance Benchmarking Tool (c) Wuping Xin 2020

- This is an open source tool subject to MIT license. 
- Source code at https://github.com/wxinix/Vissim.ComProvider/tree/master/examples/VissimBenchmark

To Run the tool
- Just double click VissimBenchmark.exe. It will sequentially run 3 scenarios, each with 600 sec simulation period:
   Scenario 1:  Run Vissim with its GUI completely HIDDEN from the desktop
   Scenario 2:  Run Vissim with the so-called "Turbo" mode, that is, QuickMode is turned on and its main GUI stops updating (on any opend data views), while the main GUI is hidden
   Scenario 3:  Run Vissim normally with its GUI showing up all the animations and data view updates

The following shows a sample benchmarking result:
	_______________________________________________________________________________________________
	Starting benchmarking Vissim on WX-NP8968

	Running Vissim with hidden Main Window now...
	Vissim Hidden Mode: takes [111810] ms to complete [600] sec simulation, realtime factor [5.366]

	Running Vissim in Turbo Mode now...
	Vissim Turbo Mode: takes [35919] ms to complete [600] sec simulation, realtime factor [16.704]

	Running Vissim with normal Main Window now...
	Vissim Visual Mode: takes [126171] ms to complete [600] sec simulation, realtime factor [4.751]

	----------------------------------------------------------------------------------------
	Mode            TimeTaken(s)    SimPeriod(s)    RealtimeFactor(x1)
	HiddenGui       111.81          600             5.4
	Turbo           35.92           600             16.7
	NormalGui       126.17          600             4.8
	----------------------------------------------------------------------------------------

	Benchmarking done. Press any key to exit.
	__________________________________________________________________________________________________

LIMITATION - the compiled VissimBenchmark.exe will benchmark Vissim version 2020. You need to have Vissim 2020 installed.
Edit and recompile the source code for other Vissim versions.